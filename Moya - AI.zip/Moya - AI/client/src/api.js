const API_URL = import.meta.env.VITE_API_URL;

export async function sendMessageToAI(provider, history) {
  try {
    const response = await fetch(`${API_URL}/api/chat/${provider}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      // YANG BERUBAH: kirim array "messages" bukan "message" doang
      body: JSON.stringify({ messages: history }), 
    });

    if (!response.ok) {
      throw new Error(`Error: ${response.status}`);
    }

    const data = await response.json();
    return data.reply;

  } catch (error) {
    console.error("Gagal fetch:", error);
    return "Maaf, Moya lagi gangguan. Coba lagi ya.";
  }
}