import { useState } from 'react'

export default function ChatInput({ onSend, disabled }) {
  const [input, setInput] = useState('')

  const handleSubmit = () => {
    onSend(input)
    setInput('')
  }

  return (
    <div className="chat-input-container">
      <input
        type="text"
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={(e) => e.key === 'Enter' &&!disabled && handleSubmit()}
        placeholder="Tanya apa saja ke Moya..."
        disabled={disabled}
      />
      <button onClick={handleSubmit} disabled={disabled}>
        {disabled? '...' : 'Kirim'}
      </button>
    </div>
  )
}