import { useState, useEffect } from 'react'
import ChatBubble from './components/ChatBubble'
import ChatInput from './components/ChatInput'
import ModelSelector from './components/ModelSelector'
import { sendMessageToAI } from './api'

const WELCOME_MESSAGE = {
  role: 'assistant',
  content: `Halo! Saya **Moya AI**\n\nSenang bisa ngobrol sama kamu. Ada yang bisa Moya bantu hari ini?`
}

function App() {
  const [messages, setMessages] = useState([])
  const [provider, setProvider] = useState('groq')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    const savedMessages = localStorage.getItem('moya_chat_history')
    if (savedMessages) {
      setMessages(JSON.parse(savedMessages))
    } else {
      setMessages([WELCOME_MESSAGE]) // Kasih greetings kalau chat kosong
    }
  }, [])

  useEffect(() => {
    if (messages.length > 0) {
      localStorage.setItem('moya_chat_history', JSON.stringify(messages))
    }
  }, [messages])

  const handleSendMessage = async (text) => {
    if (!text.trim()) return;

    const userMessage = { role: 'user', content: text }
    const newMessages = [...messages, userMessage]
    setMessages(newMessages)
    setLoading(true)

    const aiReply = await sendMessageToAI(provider, newMessages)
    const aiMessage = { role: 'assistant', content: aiReply }

    setMessages(prev => [...prev, aiMessage])
    setLoading(false)
  }

  const handleClearChat = () => {
    localStorage.removeItem('moya_chat_history')
    setMessages([WELCOME_MESSAGE])
  }

  return (
    <div className="app-container">
      <header className="header">
        <div>
          <h1>Moya AI</h1>
          <p>Asisten AI Pribadi Kamu</p>
        </div>
        <div className="header-actions">
          <ModelSelector provider={provider} setProvider={setProvider} />
          <button onClick={handleClearChat} className="clear-btn">Hapus Chat</button>
        </div>
      </header>

      <div className="chat-window">
        {messages.map((msg, i) => <ChatBubble key={i} message={msg} />)}
        {loading && <ChatBubble message={{role: 'assistant', content: 'Moya sedang mengetik...'}} />}
      </div>

      <ChatInput onSend={handleSendMessage} disabled={loading} />
    </div>
  )
}

export default App